# -*- coding:UTF-8 -*-
from re import T
from controller import Robot
from controller import Keyboard

import sys
import time
import numpy as np
import cv2
import math

X = 0
Y = 1

def getDist(a, b):
    x1, y1 = a
    x2, y2 = b
    return np.sqrt((x1-x2)**2 + (y1-y2)**2)

mapHeight = 300
mapWidth = 225
worldHeight = 6.0
worldWidth = 4.5
world2pixel = mapHeight / worldHeight
outlierCnt = 6; # 离群点检测范围
Source = (1.8, 2.5)
Target = (-1.8, -2.5)

class PID:
    """PID Controller
    """

    def __init__(self, P=0.004, I=0.0, D=0.0):

        self.Kp = P
        self.Ki = I
        self.Kd = D

        self.sample_time = 0.00
        self.current_time = time.time()
        self.last_time = self.current_time

        self.clear()

    def clear(self):
        """Clears PID computations and coefficients"""
        self.SetPoint = 0.0

        self.PTerm = 0.0
        self.ITerm = 0.0
        self.DTerm = 0.0
        self.last_error = 0.0

        # Windup Guard
        self.int_error = 0.0
        self.windup_guard = 10.0

        self.output = 0.0

    def update(self, feedback_value):
        """Calculates PID value for given reference feedback
        .. math::
            u(t) = K_p e(t) + K_i \int_{0}^{t} e(t)dt + K_d {de}/{dt}
        .. figure:: images/pid_1.png
           :align:   center
           Test PID with Kp=1.2, Ki=1, Kd=0.001 (test_pid.py)
        """
        error = self.SetPoint - feedback_value

        self.current_time = time.time()
        delta_time = self.current_time - self.last_time
        delta_error = error - self.last_error

        if (delta_time >= self.sample_time):
            self.PTerm = self.Kp * error
            self.ITerm += error * delta_time

            if (self.ITerm < -self.windup_guard):
                self.ITerm = -self.windup_guard
            elif (self.ITerm > self.windup_guard):
                self.ITerm = self.windup_guard

            self.DTerm = 0.0
            if delta_time > 0:
                self.DTerm = delta_error / delta_time

            # Remember last time and last error for next calculation
            self.last_time = self.current_time
            self.last_error = error

            self.output = self.PTerm + (self.Ki * self.ITerm) + (self.Kd * self.DTerm)

    def setKp(self, proportional_gain):
        """Determines how aggressively the PID reacts to the current error with setting Proportional Gain"""
        self.Kp = proportional_gain

    def setKi(self, integral_gain):
        """Determines how aggressively the PID reacts to the current error with setting Integral Gain"""
        self.Ki = integral_gain

    def setKd(self, derivative_gain):
        """Determines how aggressively the PID reacts to the current error with setting Derivative Gain"""
        self.Kd = derivative_gain

    def setWindup(self, windup):
        """Integral windup, also known as integrator windup or reset windup,
        refers to the situation in a PID feedback controller where
        a large change in setpoint occurs (say a positive change)
        and the integral terms accumulates a significant error
        during the rise (windup), thus overshooting and continuing
        to increase as this accumulated error is unwound
        (offset by errors in the other direction).
        The specific problem is the excess overshooting.
        """
        self.windup_guard = windup

    def setSampleTime(self, sample_time):
        """PID that should be updated at a regular interval.
        Based on a pre-determined sampe time, the PID decides if it should compute or return immediately.
        """
        self.sample_time = sample_time


class Planner(object):
    def __init__(self, map, src, dst):
        self.N = 1200
        self.expandDis = 12.0
        self.p = 0.12
        self.Map = np.zeros((mapHeight, mapWidth), np.uint8)
        self.Map.fill(255)
        self.Map = np.array(list(map))
        self.row, self.col = self.Map.shape[0], self.Map.shape[1]
        self.src = src
        self.dist = dst
        self.Path = []

    def updateMap(self, map):
        self.Map = np.array(list(map))
        self.Map = cv2.erode(self.Map, np.ones((3, 3), np.uint8), iterations = 2)     # 膨胀操作，在假设墙体更厚的情况下规划线路，减少碰撞

    def findPath(self, src):
        self.src = src
        self.RRT()  # RRT算法找到最短路径，结果保存在Path中
        for i in range(len(self.Path) - 1):
            cv2.line(self.Map, self.Path[i], self.Path[i + 1], 0, 1)
        cv2.imshow('map', self.Map)
        cv2.waitKey(1)

    def checkPath(self, a, b):
        steps = max(abs(a[X] - b[X]), abs(a[Y] - b[Y])) # 取横向、纵向较大值，确保经过的每个像素都被检测到
        xs = np.linspace(a[X], b[X], steps + 1)
        ys = np.linspace(a[Y], b[Y], steps + 1)
        for i in range(1,  steps): # 第一个节点和最后一个节点是 a，b，无需检查
            if self.Map[math.ceil(ys[i])][math.ceil(xs[i])] == 0:
                return False
        return True

    def getNearest(self, treeNodeList, sample):
        """
        :param node_list:
        :param rnd:
        :return:
        """
        d_list = [(node[X] - sample[X]) ** 2 + (node[Y] - sample[Y]) ** 2 for node in treeNodeList]
        min_index = d_list.index(min(d_list))
        return min_index

    def RRT(self):
        """
        Path planning
        animation: flag for animation on or off
        """
        treeNodeList = []
        parentList = []
        self.Path.clear()

        # 加入根节点，设置根节点的
        treeNodeList.append(self.src)
        parentList.append(-1)
        while len(treeNodeList) < self.N:
            # Random Sampling
            if np.random.random() > self.p:
                sample = np.random.randint(0, self.col), np.random.randint(0, self.row)
            else:
                sample = self.dist

            # Find nearest node
            min_index = self.getNearest(treeNodeList, sample)

            # expand tree
            nearest_node = treeNodeList[min_index]
            theta = math.atan2(sample[Y] - nearest_node[Y], sample[X] - nearest_node[X])    # 返回弧度制
            x = max(nearest_node[X] + int(self.expandDis * math.cos(theta)), 0)     # (x, y)必须在图范围内
            y = max(nearest_node[Y] + int(self.expandDis * math.sin(theta)), 0)
            x = min(x, self.col - 1)
            y = min(y, self.row - 1)
            new_node = x, y

            # 若延伸出的点和当前点之间没有碰撞，则延伸出的点是可达的，将其加入list中，并设置其父节点为当前点，否则放弃该点
            if self.checkPath(new_node, nearest_node):
                treeNodeList.append(new_node)
                parentList.append(min_index)
            else:
                continue

            # check goal
            if getDist(new_node, self.dist) <= self.expandDis:
                print("Path is found!")
                break
        
        # 回溯，得到路径Path
        Path = []
        last_index = len(treeNodeList) - 1
        Path.append(self.dist)
        while parentList[last_index] > -1:
            Path.append(treeNodeList[last_index])
            last_index = parentList[last_index]
        Path.append(self.src)
        Path.reverse()

        # 对Path进行处理，使其延较长的直线行走
        i = 0
        self.Path.append(self.src)
        while i < len(Path) - 1:
            j = i
            while j < len(Path) - 1 and self.checkPath(Path[i], Path[j + 1]):
                j += 1
            i = j
            self.Path.append(Path[i])

class Car():
    def __init__(self):
        self.velocity = 10
        self.wheels_names = ["motor1","motor2","motor3","motor4"]
        self.speed_forward =[self.velocity, self.velocity ,self.velocity ,self.velocity]
        self.speed_backward =[-self.velocity, -self.velocity ,-self.velocity ,-self.velocity]
        self.speed_leftward =[self.velocity, -self.velocity ,self.velocity ,-self.velocity]
        self.speed_rightward =[-self.velocity, self.velocity ,-self.velocity ,self.velocity]
        self.speed_leftCircle =[self.velocity, -self.velocity ,-self.velocity ,self.velocity]
        self.speed_rightCircle =[-self.velocity, self.velocity ,self.velocity ,-self.velocity]
        self.robot = Robot()  # 初始化Robot类以控制机器人
        self.mTimeStep = int(self.robot.getBasicTimeStep())  # 获取当前每一个仿真步所仿真时间mTimeStep

        # GPS
        self.gps = self.robot.getDevice('gps')
        self.gps.enable(self.mTimeStep)

        # 初始化GPS
        location_x = 0.0
        location_y = 0.0
        while self.robot.step(self.mTimeStep) != -1:
            location_x, location_y, _ = self.gps.getValues()
            if not (math.isnan(location_x) or math.isnan(location_y)):
                break

        # Inertial Unit
        self.inertial_unit = self.robot.getDevice("inertial unit")
        self.inertial_unit.enable(self.mTimeStep)

        # Lidar
        self.lidar = self.robot.getDevice("lidar")
        self.lidar.enable(self.mTimeStep)
        self.nPoints = self.lidar.getHorizontalResolution()

        self.mMotor = []
        self.speed1 = [0, 0, 0, 0]
        self.speed2 = [0, 0, 0, 0]
        self.maxVelocity = 0

        # 获取各传感器并激活，以mTimeStep为周期更新数值
        for i in range(4):
            self.mMotor.append(self.robot.getDevice(self.wheels_names[i]))
            self.mMotor[i].setPosition(float('inf'))
            self.mMotor[i].setVelocity(0.0)
            self.maxVelocity = self.mMotor[i].getMaxVelocity()

        self.pid = PID(P = 2.4, I = 0.6, D = 1.8)
        self.pid.SetPoint = 0

        self.Map = np.zeros((mapHeight, mapWidth), np.uint8)
        self.Map.fill(255)
        cv2.rectangle(self.Map, (1, 1), (mapWidth - 2, mapHeight - 2), 0, 4)
        self.planner = Planner(self.Map, (self.xy2ij(Source[X], Source[Y])), (self.xy2ij(Target[X], Target[Y])))
        self.prevTarget = Source
        self.nextTarget = Target
        
    
    # 以下两个函数实现路线规划出的点在图像上的坐标i，j与在webots中的坐标x，y之间的相互转换
    def ij2xy(self, i, j):
        x = i / world2pixel - (worldWidth / 2.0)
        y = (mapHeight - j) / world2pixel - (worldHeight / 2.0)
        return x, y

    def xy2ij(self, x, y):
        i = int((x + worldWidth / 2.0) * world2pixel)
        j = mapHeight - int((y + worldHeight / 2.0) * world2pixel)
        return i, j

    def go(self):
        while self.robot.step(self.mTimeStep) != -1:
            for i in range(4):
                self.mMotor[i].setVelocity(self.speed_forward[i])

    def turnToPoint(self, point, e):
        while self.robot.step(self.mTimeStep) != -1:
            R = self.inertial_unit.getRollPitchYaw()[0]
            location_x, location_y, _ = self.gps.getValues()
            x = point[X] - location_x
            y = point[Y] - location_y
            sin = y / math.sqrt(x ** 2 + y ** 2)
            alpha = math.asin(sin)

            # 根据x轴坐标修正alpha
            if alpha < 0:
                if x > 0:
                    alpha = - alpha - np.pi
            else:
                if x > 0:
                    alpha = np.pi - 0.0
            # 获取beta角
            beta = R + np.pi
            
            Angle = alpha + beta
            
            # Angle的绝对值要小于3.14，即转角小于180°
            if Angle < -np.pi:
                Angle += (np.pi * 2.0)
            if Angle > np.pi:
                Angle -= (np.pi * 2.0)
            
            if math.fabs(Angle) < e:
                for i in range(4):  # 暂停小车
                    self.mMotor[i].setVelocity(0)
                print('turn to point', point)
                break
            a = 0
            if Angle > 0:     # 顺时针
                a = 1
            else:             # 逆时针
                a = -1

            for i in range(4):
                self.mMotor[i].setVelocity(self.speed_rightCircle[i] * a)

    def getOut(self):
        cnt = 0
        maxcnt = 30
        self.lidarImage = []
        while self.robot.step(self.mTimeStep) != -1:
            self.car_x, self.car_y, _ = self.gps.getValues()  # 获取当前gps位置
            R = self.inertial_unit.getRollPitchYaw()[0]
            self.lidarImage = self.lidar.getRangeImage()
            if(getDist((self.car_x, self.car_y), Target)) < 0.3:  # 若达到终点则退出
                for i in range(4):  # 暂停小车
                    self.mMotor[i].setVelocity(0)
                print("Success!")
                break

            if cnt < 6:
                for i in range(4):  # 暂停小车
                    self.mMotor[i].setVelocity(0)
            # Step1: 建图
            if cnt == 6:
                for i in range(outlierCnt, self.nPoints - outlierCnt):
                    point = self.lidarImage[i]
                    
                    if math.isfinite(point) and point > 0:
                        outlierCheck = 0.0
                        for k in range(i - outlierCnt, i + outlierCnt):
                            outlierCheck += math.fabs(point - self.lidarImage[k])
                        outlierCheck /= (2 * outlierCnt)
                        if outlierCheck > 0.25 * point:
                            continue

                        worldAngle = R + math.pi - i / self.nPoints * 2.0 * math.pi
                        world_x = point * math.cos(worldAngle) + self.car_x
                        world_y = point * math.sin(worldAngle) + self.car_y
                        world_i, world_j = self.xy2ij(world_x, world_y)
                        if 0 <= world_i < mapWidth and 0 <= world_j < mapHeight:
                            cv2.circle(self.Map, (world_i, world_j), 2, 0, 1)
                self.Map = cv2.morphologyEx(self.Map, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)
                
                # Step 2
                # 规划
                self.planner.updateMap(self.Map)
                self.planner.findPath(self.xy2ij(self.car_x, self.car_y))
                self.prevTarget = (self.car_x, self.car_y)
                self.nextTarget = self.ij2xy(self.planner.Path[1][X], self.planner.Path[1][Y])
                self.turnToPoint(self.nextTarget, 0.2)  # 转向面对下一个顶点，角度误差设为0.24

            # Step3
            # 控制
            # 获取当前位置与路线之间的垂直距离d
            ''''''
            x1, y1 = self.prevTarget
            x2, y2 = self.nextTarget
            d = -((y2 - y1) * self.car_x + (x1 - x2) * self.car_y + ((x2 * y1) -(x1 * y2))) / (np.sqrt((y2 - y1)**2 + (x1 - x2)**2))

            # PID控制
            self.pid.update(d)
            self.turn = self.pid.output
            # self.turn = 0
            
            # 设置小车速度
            for i in range(4):
                self.speed1[i] = self.speed_forward[i]
                self.speed2[i] = self.speed_leftCircle[i] * self.turn

            self.speed = 0
            for i in range(4):
                self.speed = self.speed1[i] + self.speed2[i]
                if self.speed > self.maxVelocity:
                    self.speed = self.maxVelocity
                elif self.speed < -self.maxVelocity:
                    self.speed = -self.maxVelocity

                self.mMotor[i].setVelocity(self.speed)
            cnt += 1
            cnt = cnt % maxcnt


if __name__ == '__main__':
    print(sys.executable)
    print ('Python Version {}'.format(str(sys.version).replace('\n', '')))
    car = Car()  # 初始化Car类
    car.getOut()
    # car.go()
