工程中共有3个控制器pymain、pymain2、pymain3，分别对应第1、2、3张图的测试，最后测试使用的控制器为pymain3



行驶效果较好的结果录屏分别为 world1.mp4、world2.mp4、world3.mp4，而 world20.mp4、
world30.mp4 分别对应第 2、 3 张图的其他行驶情况。  




环境

Windows 11 

Python 3.9.10

Webots 2021a

OpenCV 4.5.5

Numpy 1.22.1

